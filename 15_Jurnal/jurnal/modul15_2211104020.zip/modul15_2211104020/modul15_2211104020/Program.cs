﻿class Program
{
    static void Main()
    {
        UserService userService = new UserService();

        while (true)
        {
            Console.WriteLine("\n==== MENU ====");
            Console.WriteLine("1. Registrasi");
            Console.WriteLine("2. Login");
            Console.WriteLine("3. Keluar");
            Console.Write("Pilih: ");
            string pilihan = Console.ReadLine();

            switch (pilihan)
            {
                case "1":
                    Console.Write("Masukkan username: ");
                    string username = Console.ReadLine();
                    Console.Write("Masukkan password: ");
                    string password = Console.ReadLine();
                    userService.Register(username, password);
                    break;

                case "2":
                    Console.Write("Masukkan username: ");
                    string userLogin = Console.ReadLine();
                    Console.Write("Masukkan password: ");
                    string passLogin = Console.ReadLine();
                    userService.Login(userLogin, passLogin);
                    break;

                case "3":
                    return;

                default:
                    Console.WriteLine("Pilihan tidak valid.");
                    break;
            }
        }
    }
}
