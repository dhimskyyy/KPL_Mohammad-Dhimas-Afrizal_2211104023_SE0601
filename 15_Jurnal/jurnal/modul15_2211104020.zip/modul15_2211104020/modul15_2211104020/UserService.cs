﻿using System.Text.Json;
using System.Security.Cryptography;
using System.Text;

public class UserService
{
    private string filePath = "users.json";
    private List<User> users = new List<User>();

    public UserService()
    {
        if (File.Exists(filePath))
        {
            var json = File.ReadAllText(filePath);
            users = JsonSerializer.Deserialize<List<User>>(json) ?? new List<User>();
        }
    }

    public void SaveUsers()
    {
        var json = JsonSerializer.Serialize(users, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(filePath, json);
    }

    public bool Register(string username, string password)
    {
        // Validasi panjang
        if (username.Length < 5 || username.Length > 20)
        {
            Console.WriteLine("Username harus 5-20 karakter.");
            return false;
        }

        if (password.Length < 8 || password.Length > 20)
        {
            Console.WriteLine("Password harus 8-20 karakter.");
            return false;
        }

        // Validasi karakter
        if (!username.All(char.IsLetter))
        {
            Console.WriteLine("Username hanya boleh berisi huruf alfabet.");
            return false;
        }

        if (!password.Any(char.IsDigit) || !password.Any(ch => "!@#$%^&*".Contains(ch)))
        {
            Console.WriteLine("Password harus mengandung angka dan karakter unik (!@#$%^&*).");
            return false;
        }

        if (password.ToLower().Contains(username.ToLower()))
        {
            Console.WriteLine("Password tidak boleh mengandung bagian dari username.");
            return false;
        }

        if (users.Any(u => u.Username.Equals(username, StringComparison.OrdinalIgnoreCase)))
        {
            Console.WriteLine("Username sudah digunakan.");
            return false;
        }

        var hashedPassword = HashPassword(password);
        users.Add(new User { Username = username, HashedPassword = hashedPassword });
        SaveUsers();
        Console.WriteLine("Registrasi berhasil!");
        return true;
    }

    public bool Login(string username, string password)
    {
        var hashedPassword = HashPassword(password);
        var user = users.FirstOrDefault(u => u.Username == username && u.HashedPassword == hashedPassword);
        if (user != null)
        {
            Console.WriteLine("Login berhasil!");
            return true;
        }
        Console.WriteLine("Username atau password salah.");
        return false;
    }

    private string HashPassword(string password)
    {
        using var sha256 = SHA256.Create();
        var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
        return Convert.ToBase64String(bytes);
    }
}
