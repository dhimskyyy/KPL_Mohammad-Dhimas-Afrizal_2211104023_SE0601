﻿namespace tpmodul9_2211104023.Models
{
    public class Mahasiswa
    {
        public string Nama { get; set; }
        public string Nim { get; set; }
    }
}

