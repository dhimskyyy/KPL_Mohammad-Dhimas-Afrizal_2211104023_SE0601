﻿using System;
using MatematikaLibraries;

namespace MainConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            // Contoh penggunaan fungsi-fungsi dalam library Matematika

            Console.WriteLine("FPB(60, 45) = " + Matematika.Fpb(60, 45));
            Console.WriteLine("KPK(12, 8) = " + Matematika.Kpk(12, 8));

            int[] turunanPersamaan = { 1, 4, -12, 9 };
            Console.WriteLine("Turunan dari x^3 + 4x^2 -12x + 9 adalah: " + Matematika.HitungTurunan(turunanPersamaan));

            int[] integralPersamaan = { 4, 6, -12, 9 };
            Console.WriteLine("Integral dari 4x^3 + 6x^2 -12x + 9 adalah: " + Matematika.HitungIntegral(integralPersamaan));

            Console.ReadLine();
        }
    }
}