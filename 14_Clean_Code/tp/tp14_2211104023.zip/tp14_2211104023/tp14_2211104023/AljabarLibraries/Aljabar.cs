﻿using System;

namespace AljabarLibraries
{
    public class Aljabar
    {
        // Menghitung akar-akar dari persamaan kuadrat ax^2 + bx + c
        public double[] HitungAkarPersamaanKuadrat(double[] koefisien)
        {
            double koefA = koefisien[0];
            double koefB = koefisien[1];
            double koefC = koefisien[2];

            double diskriminan = koefB * koefB - 4 * koefA * koefC;

            if (diskriminan < 0)
            {
                return new double[0]; // Tidak memiliki akar real
            }

            double akar1 = (-koefB + Math.Sqrt(diskriminan)) / (2 * koefA);
            double akar2 = (-koefB - Math.Sqrt(diskriminan)) / (2 * koefA);

            return new double[] { akar1, akar2 };
        }

        // Menghitung hasil kuadrat dari bentuk (ax + b)^2
        public double[] HitungHasilKuadrat(double[] koefisien)
        {
            double koefA = koefisien[0];
            double koefB = koefisien[1];

            double kuadratA = koefA * koefA;
            double duaAB = 2 * koefA * koefB;
            double kuadratB = koefB * koefB;

            return new double[] { kuadratA, duaAB, kuadratB };
        }
    }
}
