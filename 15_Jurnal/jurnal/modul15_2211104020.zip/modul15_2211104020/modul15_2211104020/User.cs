﻿using System.Text.Json.Serialization;

public class User
{
    public string Username { get; set; }

    [JsonIgnore] // agar password plaintext tidak diserialisasi
    public string PlainPassword { get; set; }

    public string HashedPassword { get; set; }
}
