﻿using System;
using AljabarLibraries;

namespace ConsoleAljabar
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] persamaanKuadrat = { 1, -3, -10 };
            double[] akar = Aljabar.AkarPersamaanKuadrat(persamaanKuadrat);

            Console.WriteLine("Akar-akar persamaan kuadrat:");
            Console.WriteLine($"x1 = {akar[0]}");
            Console.WriteLine($"x2 = {akar[1]}");

            double[] persamaan = { 2, -3 };
            double[] hasilKuadrat = Aljabar.HasilKuadrat(persamaan);

            Console.WriteLine("\nHasil kuadrat:");
            Console.WriteLine($"{hasilKuadrat[0]}x² {hasilKuadrat[1]}x + {hasilKuadrat[2]}");
        }
    }
}
